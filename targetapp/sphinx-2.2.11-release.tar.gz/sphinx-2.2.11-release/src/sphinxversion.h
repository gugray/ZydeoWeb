#define SPH_SVN_TAG "rel22"
#define SPH_SVN_REV 95ae9a6
#define SPH_SVN_REVSTR "95ae9a6"
#define SPH_GIT_COMMIT_ID "95ae9a6"
#define SPH_SVN_TAGREV "rel22_95ae9a6"
