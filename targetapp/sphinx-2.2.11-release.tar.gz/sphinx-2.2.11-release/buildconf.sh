#! /bin/sh

autoheader \
&& aclocal \
&& automake --foreign \
&& autoconf
